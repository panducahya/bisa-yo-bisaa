# -*- coding: utf-8 -*- 
from linepy import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from threading import Thread
from io import StringIO
from multiprocessing import Pool,Process
from urllib.parse import urlencode
from random import randint
from shutil import copyfile
import subprocess, humanize, traceback
import subprocess as cmd
import platform
import requests, json
from thrift import transport, protocol, server
from linepy.thrift.Thrift import *
from linepy.thrift.TMultiplexedProcessor import *
from linepy.thrift.TSerialization import *
from linepy.thrift.TRecursive import *
from linepy.thrift.protocol import TCompactProtocol
from linepy.thrift.transport import THttpClient
import LineService,time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
from Naked.toolshed.shell import execute_js 
from random import randint
_session = requests.session()
try:
    import urllib.request as urllib3
except ImportError:
    import urllib3

cl = LINE('panducahya969@gmail.com','panducahya26')
cl.log("Auth Token : " + str(cl.authToken))
MySelf = cl.getProfile()
print("My MID : " + MySelf.mid)
#________________________________________  
whiteListedMid = ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","uf38d69f0733abb61c72c90a162c13647","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72","u0f13117cf1e1444cd8cdc2ae87d9f050"]
mymid = ['u1e812bcfc29ed4d9eae95a64a59b9568']
admin = ['u1e812bcfc29ed4d9eae95a64a59b9568']
print ('_____________________')
#________________________________________  
oepoll = OEPoll(cl)
MySelf.mid = cl.getProfile().mid
zxcv = MySelf.mid
kickcl = []
kickjs = []
kikel = []
gaspol = []
Kibar = []
Foto = {"foto":{}}
settings = {
	"batasfast":0.004999,
	"keyCommand":"",
    "group":{}
	}
status = 6
wait = {
	"Blacklist":[],
	"mode":False,
	"autojoin":True,
	"tempat":True,
	"flashmode":False
	}
mulai = time.time()
def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
    
def lineBot(op):
        global time
        global ast
        global groupParam
        global multiprocessing
        global subprocess
        global threading
        try:
            if op.type == 0:
                return
            if op.type == 11:
             if wait["flashmode"] == True:
              if wait["mode"] == True:
               if op.param2 not in whiteListedMid and op.param2 not in admin:
               	sikat = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()
               	kunci = threading.Thread(target=lockunicode, args=(op.param1,)).start()
             else:
             	if wait["mode"] == True:
             	 if op.param2 not in whiteListedMid and op.param2 not in admin:
             	     sikat = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()
             	     kunci = threading.Thread(target=lockunicode, args=(op.param1,)).start()
             	     input3 = threading.Thread(target=black, args=(op.param2,)).start()
                	    
            if op.type == 11:
             if wait["flashmode"] == False:
              if wait["mode"] == True:
               if op.param2 not in whiteListedMid and op.param2 not in admin:
               	input3 = threading.Thread(target=black, args=(op.param2,)).start()
               	kunci = threading.Thread(target=lockunicode, args=(op.param1,)).start()
             else:
             	if wait["mode"] == True:
             	 if op.param2 not in whiteListedMid and op.param2 not in admin:
             	     sikat = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()
             	     kunci = threading.Thread(target=lockunicode, args=(op.param1,)).start()
             	     input3 = threading.Thread(target=black, args=(op.param2,)).start()
#________________________________________                	    
            if op.type == 13:
            	if wait["flashmode"] == True:
            	    for jembut in wait["Blacklist"]:
            	        canceling = threading.Thread(target=ccl2, args=(op.param1, jembut)).start()

            if op.type == 13:
                if MySelf.mid in op.param3:
                    cl.acceptGroupInvitation(op.param1)
                    if wait["autojoin"] == True:
                    	if op.param2 in whiteListedMid or op.param2 in admin:
                    	    pass
                    	else:
                    	    cl.acceptGroupInvitation(op.param1)

            if op.type == 13:
             if wait["flashmode"] == False:
              if op.param3 in wait["Blacklist"]:
               if op.param2 not in whiteListedMid and op.param2 not in admin:
               	input2 = threading.Thread(target=black, args=(op.param2,)).start()
             else:
             	if op.param3 in wait["Blacklist"]:
             	 if op.param2 not in whiteListedMid and op.param2 not in admin:
             	     input3 = threading.Thread(target=black, args=(op.param2,)).start()
             	     tampol = threading.Thread(target=tium, args=(op.param1, op.param2)).start()
#________________________________________                	    
            if op.type == 17:
                if wait["mode"] == True:
                 if op.param2 in wait["Blacklist"]:
                  if op.param2 not in whiteListedMid and op.param2 not in admin:
                  	kunci2 = threading.Thread(target=lockqr, args=(op.param1,)).start()
                  	wait["mode"] = True
                 else:
                 	pass
                else:
                	if wait["mode"] == True:
                	 if op.param2 not in whiteListedMid and op.param2 not in admin:
                	     tampol = threading.Thread(target=tium2, args=(op.param1, wait["Blacklist"])).start()

            if op.type == 17:
                if op.param2 in wait["Blacklist"]:
                 if wait["mode"] == False:
                  if op.param2 not in whiteListedMid and op.param2 not in admin:
                  	tampol = threading.Thread(target=tium2, args=(op.param1, wait["Blacklist"])).start()
                  	wait["mode"] = True
                 else:
                 	pass
                else:
                	if wait["mode"] == True:
                	 if op.param3 not in whiteListedMid and op.param2 not in admin:
                	     input4 = threading.Thread(target=black, args=(op.param2,)).start()
#________________________________________   
            if op.type == 19:
             if wait["flashmode"] == False:
              if op.param3 in whiteListedMid:
               if op.param2 not in whiteListedMid and op.param2 not in admin:
               	invite = threading.Thread(target=bkp, args=(op.param1,op.param2,wait["Blacklist"])).start()
             else:
             	if op.param3 in whiteListedMid:
             	 if op.param2 not in whiteListedMid and op.param2 not in admin:
             	     invite = threading.Thread(target=bkpflash, args=(op.param1,op.param2,wait["Blacklist"])).start()

            if op.type == 19:
             if op.param3 in admin:
              #if wait["mode"] == False:
               if op.param2 not in whiteListedMid and op.param2 not in admin:
               	input = threading.Thread(target=black, args=(op.param2,)).start()
               	invite2 = threading.Thread(target=bkpo, args=(op.param1,op.param3)).start()
               	tampol = threading.Thread(target=tium, args=(op.param1, wait["Blacklist"])).start()

#________________________________________                	    
            if op.type == 32:
             if wait["flashmode"] == False:
              if op.param3 in whiteListedMid:
               if op.param2 not in whiteListedMid and op.param2 not in admin:
               	input4 = threading.Thread(target=black, args=(op.param2,)).start()
             else:
             	if op.param3 in whiteListedMid:
             	 if op.param2 not in whiteListedMid and op.param2 not in admin:
             	     invite3 = threading.Thread(target=bkpflash, args=(op.param1,op.param2,wait["Blacklist"])).start()
#________________________________________                	                 
            if op.type == 25 or op.type == 26:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.contentType == 1:
                	if MySelf.mid in Foto["foto"]:
                		if msg._from in admin:
                			try:
                				path = cl.downloadObjectMsg(msg_id)
                				cl.updateProfilePicture(path)
                				del Foto["foto"][MySelf.mid]
                				cl.sendMessage(msg.to,"Foto berhasil dirubah")
                			except:
                				path = cl.downloadObjectMsg(msg_id)
                				cl.updateProfilePicture(path)
                				del Foto["foto"][MySelf.mid]
                				cl.sendMessage(msg.to,"Foto berhasil dirubah")
                if msg.toType == 2:
                	if msg.toType == 0:
                	     to = msg._from
                	elif msg.toType == 2:
                	     to = msg.to
                	if msg.contentType == 0:
                	  if text is None:
                	      return
                	  else:
                	      cmd = command(text)
                	      cmd = " ".join(cmd.split())
                	  for cmd in cmd.split(' n '):
                	      if cmd == "sp":
                	             if msg._from in admin:
                	                 flash = threading.Thread(target=speedbot, args=(msg.to,)).start()
                
                	      if cmd == "foto":
                	          if msg._from in admin:
                	              Foto["foto"][MySelf.mid] = True
                	              cl.sendMessage(msg.to,"Kirim fotonya..")
                
                	      if cmd == "respon":
                	             if msg._from in admin:
                	                 cl.sendMessage(msg.to,"Respon all bots ")
           
                	      if text.lower() == "kikel on":
                	             if msg._from in admin:
                	                 wait["kikil"] = True
                	                 cl.sendMessage(msg.to," Kikel Ready ✅")

                	      if text.lower() == "kikel off":
                	             if msg._from in admin:
                	                 wait["kikil"] = False
                	                 cl.sendMessage(msg.to," Kikel Off ✅")

                	      if cmd == "out":
                	             if msg._from in admin:
                	                 cl.leaveGroup(to)

                	      if cmd == "join":
                	             if msg._from in admin:
                	                 cl.acceptGroupInvitation(to)
                	         
                	      if cmd == "glist":
                	           if msg._from in admin:
                	               ma = ""
                	               a = 0
                	               gid = cl.getGroupIdsJoined()
                	               for i in gid:
                	                   G = cl.getGroup(i)
                	                   a = a + 1
                	                   end = "\n"
                	                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                	               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                	      if cmd.startswith("kikelonto "):
                	          if msg._from in admin:
                	              separate = text.split(" ")
                	              number = text.replace(separate[0] + " ","")
                	              groups = cl.getGroupIdsJoined()
                	              ret_ = ""
                	              try:
                	                  group = groups[int(number)-1]
                	                  kikel.append(group)
                	                  cl.sendMessage(msg.to,"mode kikel on to group "+cl.getGroup(group).name)
                	              except:pass

                	      if cmd == "restart":
                	          if msg._from in admin:
                	              cl.sendMessage(msg.to,'process')
                	              restartBot()

                	      if cmd == "outallgrup":
                	          if msg._from in admin:
                	              gid = cl.getGroupIdsJoined()
                	              for i in gid:
                	                  if i not in msg.to:
                	                      cl.leaveGroup(i)
                	              cl.sendMessage(msg.to, 'bye - bye')

                	      if cmd == "listadmin":
                	          if msg._from in admin:
                	              if admin == []:
                	                  pass
                	              else:
                	                  mc = "[Daftar Bosqyu] "
                	                  num=1
                	                  ragets = cl.getContacts(admin)
                	                  for mi_d in ragets:
                	                      mc+="\n%i. %s" % (num, mi_d.displayName)
                	                      num=(num+1)
                	                  mc+="\n\nAda [%i] User" % len(ragets)
                	                  cl.sendMessage(msg.to, mc)

                	      if cmd == "bl":
                	          if msg._from in admin:
                	              datakick = "Blacklist : %i\n"% len(kickcl)
                	              total = 0
                	              total += len(kickcl)
                	              datakick += 'total {}'.format(total)
                	              cl.sendMessage(msg.to, datakick)

                	      if cmd == "cb":
                	          if msg._from in admin:
                	              if wait["Blacklist"] == []:
                	                  cl.sendMessage(msg.to,"Tidak ada sampah")
                	              else:
                	                  mc = "[Daftar Sampah] "
                	                  num=1
                	                  ragets = cl.getContacts(wait["Blacklist"])
                	                  for mi_d in ragets:
                	                      mc+="\n%i. %s" % (num, mi_d.displayName)
                	                      num=(num+1)
                	                  mc+="\n\n [%i] Sampah Berhasil di Hapus ✅" % len(ragets)
                	                  cl.sendMessage(msg.to, mc)
                	                  wait["Blacklist"] = []
                	                  wait["mode"] = False
                	                  wait["tempat"] = True
                	                  tarung = []
                
                	      if cmd.startswith("joinall"):
                	          if msg._from in admin:
                	              gid = cl.getGroupIdsJoined()
                	              for i in gid:
                	                  G = cl.getGroup(i)
                	                  G.preventedJoinByTicket = False
                	                  cl.updateGroup(G)
                	                  invsend = 0
                	                  Ticket = cl.reissueGroupTicket(i)
                	                  for MySelf in whiteListedMid:
                	                         try:
                	                             cl.acceptGroupInvitationByTicket(i, Ticket)
                	                         except:pass
                
                	      if "Tium@" in msg.text:
                	         if msg._from in admin:
                	             nk0 = msg.text.replace("Tium@","")
                	             nk1 = nk0.lstrip()
                	             nk2 = nk1.replace("","")
                	             nk3 = nk2.rstrip()
                	             _name = nk3
                	             gs = cl.getGroup(msg.to)
                	             Bl = []
                	             for s in gs.members:
                	                 if _name in s.displayName:
                	                    if s.mid not in whiteListedMid and s.mid not in whiteListedMid:
                	                        wait["Blacklist"].append(s.mid)
                	                        Bl.append(s.mid)
                	             wait["tempat"] = False
                	             Kibar.append(msg.to)
                	             sleding = Thread(target=tium2, args=(msg.to, wait["Blacklist"]))
                	             sleding.start()
                	             cl.sendMessage(msg.to,"%i User Blacklist Terlihat"% len(Bl))
                
                	      if "Kick @" in msg.text:
                	         if msg._from in admin:
                	             nk0 = msg.text.replace("Kick @","")
                	             nk1 = nk0.lstrip()
                	             nk2 = nk1.replace("","")
                	             nk3 = nk2.rstrip()
                	             _name = nk3
                	             gs = cl.getGroup(msg.to)
                	             #targets = []
                	             for s in gs.members:
                	                 if _name in s.displayName:
                	                    #targets.append(s.mid)
                	                    wait["Blacklist"].append(s.mid)
                	             wait["tempat"] = False
                	             Kampang.append(msg.to)
                	             key = eval(msg.contentMetadata["MENTION"])
                	             key["MENTIONEES"][0]["M"]
                	             targets = []
                	             for x in key["MENTIONEES"]:
                	                 targets.append(x["M"])
                	             for target in targets:
                	                 if target in whiteListedMid and target in wait["Blacklist"]:
                	                     pass
                	                 else:
                	                     wait["Blacklist"].append(target)
                	                     try:cl.kickoutFromGroup(msg.to,[target])
                	                     except:cl.sendMessage(msg.to,'limit')

                	      if ("Spaminv " in msg.text):
                	          if msg._from in admin:
                	              try:
                	                  text = msg.text.replace("Spaminv ","")
                	                  split = text.split("@")
                	                  namaGrup = split[1]
                	                  jmlh = 0
                	                  try:jmlh = int(split[2])
                	                  except:cl.sendMessage(msg.to,"Group Name Can't use spaces")
                	                  midd = split[3]
                	                  cl.findAndAddContactsByMid(midd)
                	                  try:
                	                      gas = Thread(target=spam, args=(msg.to,namaGrup,midd,jmlh))
                	                      gas.start()
                	                  except:pass
                	              except Exception as e:
                	                  cl.log("ERROR SPAM INV: "+str(e))

                	      elif "/ti/g/" in msg.text.lower():
                	          link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                	          links = link_re.findall(text)
                	          n_links = []
                	          for l in links:
                	             if l not in n_links:
                	                n_links.append(l)
                	          for ticket_id in n_links:
                	             group = cl.findGroupByTicket(ticket_id)
                	             cl.acceptGroupInvitationByTicket(group.id,ticket_id)

        except Exception as e:
            print(e)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def kutis(grup, targets):
    gMembMids = targets
    matched_list = []
    if matched_list != []:
    	pass
    for tag in wait["Blacklist"]:
    	matched_list+=filter(lambda str: str == tag, gMembMids)
    if matched_list == []:
    	pass
    	return
    for jembut in matched_list:
    	try:
    	    cl.kickoutFromGroup(grup, [jembut])
    	    print (msg.to,[macet])
    	except:pass
    
def speedbot(grup):
		start = time.time()
		elapsed_time = time.time() - start
		jem = time.time() - start
		cl.sendMessage(grup, "%.0f ms\n%.5f second" % (jem*10000,elapsed_time))

def cium(grup, target):
    try:
        asd= cl.kickoutFromGroup(grup, [target])
        if asd != None:
            galaxyfail
    except:pass
    print("NOTIF_CIUM_")

def spam(grup,nama,mid,jmlh):
	try:
		while jmlh > 0:
			group = cl.createGroup(nama,[mid])
			group_id = group.id
			cl.leaveGroup(group_id)
			jmlh = jmlh - 1
		cl.sendMessage(grup,'sukses...')
	except:pass

def tium(grup, targets):
    gMembMids = targets
    matched_list = []
    if matched_list != []:
    	pass
    for tag in wait["Blacklist"]:
    	matched_list+=filter(lambda str: str == tag, gMembMids)
    if matched_list == []:
    	pass
    	return
    for tag in wait["Blacklist"]:
    	matched_list+=filter(lambda str: str == tag, gMembMids)
    if matched_list == []:
    	pass
    	return
    for jembut in matched_list:
    	try:
    	    cl.kickoutFromGroup(grup, [jembut])
    	    kickcl.append(jembut)
    	except:pass
    print("NOTIF_TIUM_")

def tium2(grup, targets):
	gMembMids = targets
	matched_list = []
	if matched_list != []:
		pass
	for tag in wait["Blacklist"]:
		matched_list+=filter(lambda str: str == tag, gMembMids)
	if matched_list == []:
		pass
		return
	try:
		cl.inviteIntoGroup(grup, ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72"])
		kickjs(grup,matched_list)
	except:cl.sendMessage(grup,'limit')
	print("NOTIF_TIUM2_")

def tium3(grup):
	group = cl.getGroup(grup)
	gMembMids = [contact.mid for contact in group.members]
	matched_list = []
	if matched_list != []:
		pass
	for tag in whiteListedMid:
		matched_list+=filter(lambda str: str == tag, gMembMids)
	if matched_list:
		pass
	else:
		time.sleep(0.2)
		kickjs(grup,wait['Blacklist'])

def kickjs(grup,blaklist):
	try:
		cmd = 'kickall.js gid={} token={}'.format(grup, cl.authToken)
		for t in blaklist:
			if t not in admin:
				cmd += ' uid={}'.format(t)
		success = execute_js(cmd)
		squad = ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72"]
		cl.inviteIntoGroup(grup, squad)
	except:pass
	print ('NOTIF_KICK_JS')

def ccl2(grup, target):
    try:cl.cancelGroupInvitation(grup, [target])
    except:pass
    
def bkp(grup, target,sasaran):
    black(target)
    try:
        cl.inviteIntoGroup(grup, ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72"])
        time.sleep(0.3)
        gaspol = threading.Thread(target=kickjs, args=(grup,sasaran)).start()
    except:invasis(grup, sasaran)
    print("NOTIF_INV_KICK_")
    
def invasis(grup, sasaran):
	try:
		cl.inviteIntoGroup(grup, ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72"])
		gascl = threading.Thread(target=kickjs, args=(grup,wait["Blacklist"])).start()
		gtb = ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72"]
		time.sleep(0.5)
		cl.inviteIntoGroup(grup, gtb)
		wait["flashmode"] = True
		try:acc = threading.Thread(target=cl.acceptGroupInvitation, args=(grup,)).start()
		except:pass
	except:invasisqr(grup)
	gMembMids = sasaran
	matched_list = []
	if matched_list != []:
		pass
	for tag in wait["Blacklist"]:
		matched_list+=filter(lambda str: str == tag, gMembMids)
	if matched_list == []:
		pass
		return
	for jembut in matched_list:
		try:
			cl.kickoutFromGroup(grup, [jembut])
			kickcl.append(jembut)
		except:pass
	print("NOTIF_INVASIS_")

def bkpflash(grup, target,sasaran):
    black(target)
    try:
        gtb = ["u1e812bcfc29ed4d9eae95a64a59b9568","uafafac5c1ce1796ef36c4260e476c520","ube37b6f9e7531043f3914a5da0883779","u4f97f7fee3126f6524013e40a1019628","u78a739fab94aef6094b2e1f9b4d85f87","u5add75c7cb29a76635dce138334e7475","u4a13cbe7471c74870ac828ef50ef1f1a","ua1fab51153eb593a6c9b3496ba6c5e72"]
        cl.inviteIntoGroup(grup, gtb)
        acc = threading.Thread(target=cl.acceptGroupInvitation, args=(grup,)).start()
    except:invasisqr(grup)
    gMembMids = sasaran
    matched_list = []
    if matched_list != []:
    	pass
    for tag in wait["Blacklist"]:
    	matched_list+=filter(lambda str: str == tag, gMembMids)
    if matched_list == []:
    	pass
    	return
    for jembut in matched_list:
    	try:
    	    cl.kickoutFromGroup(grup, [jembut])
    	    kickcl.append(jembut)
    	except:pass
    print("Flash mode ON!")

def bkpo(grup, target):
    try:
        cl.findAndAddContactsByMid(target)
        cl.inviteIntoGroup(grup, [target])
    except:pass
    print("NOTIF_INVITE_")
    
def black(target):
    if target not in wait["Blacklist"] and target not in whiteListedMid and target not in admin:
        wait["Blacklist"].append(target)

def lockqr(grup):
    G = cl.getGroup(grup)
    G.preventedJoinByTicket = True
    try:
        asd= cl.updateGroup(G)
        if asd != None:
            galaxyfail
    except:
        pass
    print("NOTIF_QR")
    
def lockunicode(grup):
    G = cl.getGroup(grup)
    G.preventedJoinByTicket = False
    try:
        cl.updateGroup(G)
        Ticket = cl.reissueGroupTicket(grup)
        join = threading.Thread(target=accqr, args=(grup,Ticket)).start()
    except:
        pass
    print("NOTIF_UNICODE_")

def invasisqr(grup):
    wait["flashmode"] = True
    G = cl.getGroup(grup)
    G.preventedJoinByTicket = False
    try:
        cl.updateGroup(G)
        Ticket = cl.reissueGroupTicket(grup)
        joinall = threading.Thread(target=accqr, args=(grup,Ticket)).start()
    except:
        pass
    print("NOTIF_INVASIS_QR")

def accqr(grup, Ticket):
    try:cl.acceptGroupInvitationByTicket(grup, Ticket)
    except:pass
    gMembMids = wait["Blacklist"]
    matched_list = []
    if matched_list != []:
    	pass
    for tag in wait["Blacklist"]:
    	matched_list+=filter(lambda str: str == tag, gMembMids)
    if matched_list == []:
    	pass
    	return
    for jembut in matched_list:
    	try:
    	    cl.kickoutFromGroup(grup, [jembut])
    	    kickcl.append(jembut)
    	except:pass
    print("NOTIF_ACC_QR")

def command(text):
        pesan = text.lower()
        if pesan.startswith(settings["keyCommand"]):
        	cmd = pesan.replace(settings["keyCommand"],"")
        else:
        	cmd = "command"
        return cmd
        
while True:
	try:
		ops = oepoll.singleTrace(count=50)
		if ops != None:
			for op in ops:
				oepoll.setRevision(op.revision)
				flashbot = threading.Thread(target=lineBot, args=(op,))
				flashbot.deamon = True
				flashbot.start()
				#
	except Exception as e:
		print (e)
